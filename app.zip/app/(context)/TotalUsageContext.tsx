import {createContext} from 'react';
export const totalUsageContext=createContext<any>(0);